package org.osmtracker.exception;

public class ExportTrackException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public ExportTrackException(String message) {
		super(message);
	}

}
