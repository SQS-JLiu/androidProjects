package org.osmtracker.exception;

public class CreateTrackException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public CreateTrackException(String message) {
		super(message);
	}

}
