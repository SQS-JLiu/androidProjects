[<img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png' height="80"/>](https://play.google.com/store/apps/details?id=org.osmtracker)
[<img src="https://f-droid.org/badge/get-it-on.png" alt="Get it on F-Droid" height="80">](https://f-droid.org/app/org.osmtracker)

OSMTracker for Android™ official source code repository is [https://github.com/nguillaumin/osmtracker-android](https://github.com/nguillaumin/osmtracker-android).

[![Build Status](https://travis-ci.org/nguillaumin/osmtracker-android.svg?branch=master)](https://travis-ci.org/nguillaumin/osmtracker-android)

For more information about the project, documentation and bug reports please visit https://github.com/nguillaumin/osmtracker-android/wiki

To help translate OSMTracker, please visit https://www.transifex.com/projects/p/osmtracker-android/
