<img src="playstore/archwiki_feature_graphic.png" height="150"/>

ArchWiki Viewer
===============
A simple viewer for the Arch Linux Wiki. Page content is formatted for optimal mobile viewing.

[<img src="https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png" alt="Get it on Google Play" height="80">](https://play.google.com/store/apps/details?id=com.jtmcn.archwiki.viewer) [<img src="https://f-droid.org/badge/get-it-on.png" alt="Get it on F-Droid" height="80"><br/>](https://f-droid.org/repository/browse/?fdid=com.jtmcn.archwiki.viewer)

## Screenshots

<img src="playstore/screen1.png" width="170"/> <img src="playstore/screen2.png" width="170"/> <img src="playstore/screen3.png" width="170"/> <img src="playstore/screen4.png" width="170"/> <img src="playstore/screen5.png" width="170"/>

## Contributions
All contributions are welcome, don't forget to ask if you need help.

Comments and tests are highly encouraged.

## License
This project is licensed under the Apache License, Version 2.0

Copyright 2014 jtmcn

See [LICENSE.md](LICENSE.md)
