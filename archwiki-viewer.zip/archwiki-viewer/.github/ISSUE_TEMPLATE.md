<!-- Remove any sections that aren't applicable.
Replace the empty checkboxes [ ] below with checked ones [x] accordingly -->

I have:
- [ ] searched open and closed issues for duplicates
- [ ] provided a reproducible result if applicable

----------------------------------------

<!-- If this isn't a bug report remove the sections below -->
### Bug description
Describe here the issue that you are experiencing.

### Steps to reproduce 
- using hyphens as bullet points
- list the steps
- that reproduce the bug

**Actual result:** Describe here what happens after you run the steps above (i.e. the buggy behaviour)
**Expected result:** Describe here what should happen after you run the steps above (i.e. what would be the correct behaviour)

### Device info
<!-- replace the examples with your info -->
**Device:** Manufacturer Model XVI
**Android version:** 0.0.0
**App version:** 0.0.0
