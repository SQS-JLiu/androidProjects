package com.phikal.regex.Games;

public class TaskGenerationException extends Exception {
    public TaskGenerationException(String msg) {
        super(msg);
    }
}
