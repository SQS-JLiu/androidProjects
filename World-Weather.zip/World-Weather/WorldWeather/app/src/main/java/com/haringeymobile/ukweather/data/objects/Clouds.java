package com.haringeymobile.ukweather.data.objects;

import com.google.gson.annotations.SerializedName;

public class Clouds {

    @SerializedName("all")
    private int cloudinessPercentage;
}
