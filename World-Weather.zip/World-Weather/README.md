# World-Weather
An Android app that uses the Open Weather Map (https://openweathermap.org/API) to display current weather conditions and weather forecast in selected world cities.

The app is available to download on:
- [Google Play Store](https://play.google.com/store/apps/details?id=com.haringeymobile.ukweather)
- [F-Droid](https://f-droid.org/packages/com.haringeymobile.ukweather/)
