package com.frrahat.quransimple;

public class AyahInformationContainer {
	public static String aayatESajdahString="***(Aayat e Sajdah)***";
	public static int aayatESajdahs[]={
		7,206,
		13,15,
		16,50,
		17,109,
		19,58,
		22,18,
		22,77,//(Shafi)
		25,60,
		27,26,
		32,15,
		38,24,//(Hanafi)
		41,38,
		53,62,
		84,21,
		96,19};
}
